# Spark — homepage & site (static rebuild)

A conversion-focused, SEO-friendly rebuild of the Spark solar/battery website,
recreated from the Claude Design export as **plain static HTML/CSS/JS with no
runtime dependency** (no React, no build step).

## Structure

- `*.html` — 31 pages (home, product pages, guides, 11 city landing pages,
  quote flow, reviews, legal, etc.). Layout/styling is inlined per page,
  faithful to the original design.
- `styles.css` — shared reset + font fallbacks.
- `app.js` — shared interactions: FAQ accordions, live chat, savings/heat-pump/EV
  calculators, animated bill chart, mobile sticky CTA, form success states.
- `flows.js` — the stateful flows: get-a-quote 3-step wizard, EV charger cart
  (localStorage) + drawer, and EV checkout.
- `assets/` — WebP images + `favicon.svg`.
- `robots.txt`, `sitemap.xml`, `vercel.json`.

## Deploy to Vercel

This is a static site — no framework, no build command needed.

**Option A — CLI**
```bash
cd site
vercel deploy          # preview
vercel deploy --prod   # production
```

**Option B — Dashboard**
Go to https://vercel.com/new and drag this `site/` folder in.

**Option C — Git (auto-deploys)**
Push this repo to GitHub/GitLab and "Import Project" in Vercel. Set the
**Root Directory** to `site/` and leave the framework preset as **Other**
(no build command, output = the directory itself).

## Notes

- Accreditation marks (Which?, MCS, TrustMark, NAPIT, HIES, EPVS) render as
  branded text badges — drop the real logo PNGs into `assets/` and swap the
  badge markup for `<img>` tags to use the official artwork.
- Forms and live chat are front-end prototypes (no backend wired). Connect the
  form submits to your CRM/email and the chat to a provider when ready.
